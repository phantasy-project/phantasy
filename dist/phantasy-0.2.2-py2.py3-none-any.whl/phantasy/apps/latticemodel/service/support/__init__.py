# encoding: UTF-8
#
# Copyright (c) 2015 Facility for Rare Isotope Beams
#

"""
Simulation engine (ie IMPACT, TLM) support package. 
"""
