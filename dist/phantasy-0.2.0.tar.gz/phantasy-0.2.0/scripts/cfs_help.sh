#!/bin/bash

#
# print help about controling channel finder serivce
#
# Tong Zhang <zhangt@frib.msu.edu>
# 2016-12-08 14:14:09 PM EST

echo -e "How to control Channel Finder Serivce:"
echo -e "  +--------------------+-------------------+"
echo -e "  |     script name    |    description    |"
echo -e "  +--------------------+-------------------+"
echo -e "  | cfs_start.sh       |  start service    |"
echo -e "  | cfs_stop.sh        |  stop service     |"
echo -e "  | cfs_empty_index.sh |  empty index      |"
echo -e "  | cfs_build_index.sh |  build index      |"
echo -e "  | cfs_test_push.py   |  push data to cfs |"
echo -e "  +--------------------+-------------------+"
