phantasy
========

Physics High-level Applications and Toolkits for Accelerator SYstem.

Refactored from repos: ``phyapps`` and ``phyhlc``.

- Create a new name for this project;
- Refactor software framework;
- Get rid of global variables;
- Rebuild API systematically, make import process more easy;
- Add more docs and examples;
- Add more packages/modules upon this new framework.

---------------------------------------------------------------------------

Tong Zhang

2016-12-19 17:19:31 PM EST
