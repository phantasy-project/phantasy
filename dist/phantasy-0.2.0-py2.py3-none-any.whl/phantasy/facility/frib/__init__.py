"""FRIB specific configurations"""

# configuration namelist

from ._conf_std import INI_DICT
from ._conf_std import generate_inifile
