#!python
# -*- coding: utf-8 -*-

"""Lattice model application.
"""

import sys

if __name__ == '__main__':
    from phantasy.apps import lmapp
    sys.exit(lmapp.main())
