from .frib import INI_DICT as FRIB_INI_DICT
