#!/bin/bash

#
# stop channel finder service
# 
# Tong Zhang <zhangt@frib.msu.edu>
# 2016-12-02 14:34:17 PM EST
#

asadmin stop-domain

