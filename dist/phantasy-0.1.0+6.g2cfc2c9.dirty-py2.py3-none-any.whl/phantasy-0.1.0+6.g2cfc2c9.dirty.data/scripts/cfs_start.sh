#!/bin/bash

#
# start channel finder service
# 
# Tong Zhang <zhangt@frib.msu.edu>
# 2016-12-02 14:33:04 PM EST
#

asadmin start-domain

