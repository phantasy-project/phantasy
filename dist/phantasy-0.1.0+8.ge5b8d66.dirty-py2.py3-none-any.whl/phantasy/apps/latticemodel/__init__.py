# encoding: UTF-8
#
# Copyright (c) 2015 Facility for Rare Isotope Beams
#

"""
Lattice Model application package.
"""

from .service import app as lmapp
